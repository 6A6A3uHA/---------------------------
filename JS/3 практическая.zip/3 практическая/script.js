const del = document.getElementById("delete")
const verify_name = /^[А-Я][а-я]{1,}$/
const verify_date = /(0[1-9]|[1-2][0-9]|3[01])\.(0[1-9]|1[0-2])\.(19[0-9][0-9]|20[01][0-9]|202[0-5])/
const form_account = document.forms.form_account
const err_account = document.getElementsByClassName("err")
const account_information = document.getElementById("account")
const nolog = document.getElementsByClassName("nologin")
const reg = document.getElementById("reg")
const test = document.getElementById("test")
const result = document.getElementById("result")
const unreg = document.getElementById("logout")
const test_or_result = {"inp":`input type="radio"`, "p":`p`}
const end_p = {"inp": "", "p":`</p>`}
const btn_test = document.getElementById("btn_test")
const old_try = document.getElementById("old_try")
const leader_board = document.getElementById("leader_board")
let form_test = document
let list_rezult = {}
let account = new Object();
let stroka = ""
let session = 0
let b = 0
console.log(account);

// localStorage.clear()
session = localStorage.getItem("active_session")
let old = 0
setInterval(() => {
    if (old != session) {
        console.log("active_session =",session);
        old = session
    }
}, 1000);

 
if (session != "0" && session != null && session != "null") 
    {account = JSON.parse(localStorage.getItem(session))
    console.log(account);    
    stroka=`Имя:${account.name}\nДата:${account.date}\nПол:${account.sex}`
    account_information.innerText = stroka
    for ( let i = 0; i<nolog.length;i++) {nolog[i].classList.remove("hide")}
    look_test()}
else
    {for ( let i = 0; i<nolog.length;i++) {nolog[i].classList.add("hide")}}

function local_or_no(localStorage_or_no) 
    {if (localStorage_or_no == "localStorage") {otvet = true;console.log("Место это локальное хранилище");}
    else{otvet=false; console.log("Место это локальная переменная");}
    return(otvet)}

function check_object_to_have_add_attribute(localStorage_or_no, mb_full_key, value = null) 
    {if (local_or_no(localStorage_or_no)) 
        {console.log("Обращение к локальному хранилищу");
        if (value != null) {otvet = localStorage.getItem(mb_full_key) == JSON.stringify(value);console.log("Адрес",mb_full_key,"соответствует значению", value,"в локальном хранилище", otvet);}
        else{otvet = localStorage.getItem(mb_full_key) == null; console.log("Адрес",mb_full_key,"в локальном хранилище свободен", otvet);}
        }

    else
        {console.log("Обращение к локальной переменной");
        if (value != null) {otvet = localStorage_or_no[mb_full_key] == value || JSON.stringify(localStorage_or_no[mb_full_key]) == JSON.stringify(value); console.log("Адрес",mb_full_key,"соответствует значению", value,"в локальной переменной", otvet);}
        else{otvet = localStorage_or_no[mb_full_key] == undefined;console.log("Адрес",mb_full_key,"в локальной переменной свободен", otvet);}
        }
    return(otvet)}

function setactive(localStorage_or_no, full_key, active_key) 
    {console.log("Установка активного события Место установки", localStorage_or_no, "Название события", active_key, "Значение события", full_key);
    if (local_or_no(localStorage_or_no)) { if (active_key != 0) {console.log("Выполнено в локальное хранилище"); localStorage.setItem(active_key, full_key)} }
    else{ if (active_key!=0) {console.log("Выполнено в локальную переменную");localStorage_or_no[active_key] = full_key} else{console.log("Не выполнено");
    }}}


function get_key(find_key, localStorage_or_no, value = null) 
    {let key = -1
    let mb_full_key
    console.log("Сработал поиск ключа");
    
    for (let b = 0; b <= Object.keys(localStorage_or_no).length+1; b++) 
        { mb_full_key = (`${find_key}${b}`)
        console.log(mb_full_key);
        if (check_object_to_have_add_attribute(localStorage_or_no, mb_full_key, value)) 
            {key = mb_full_key; console.log("Найдено существующее значение"); break} }

    if (key == -1) {
        console.log("Существующего значния не найдено");
        for (let c = 0; c <= Object.keys(localStorage_or_no).length+1; c++) 
            { mb_full_key = (`${find_key}${c}`);
            console.log(mb_full_key);
            if (check_object_to_have_add_attribute(localStorage_or_no, mb_full_key)) 
            {key = mb_full_key; console.log("Найдено свободное значение"); break} }
        
    }
    return(key)
    }

function set_object_new_attribute(find_key, value, localStorage_or_no="localStorage", add_active=0) 
    { let full_key = get_key(find_key, localStorage_or_no, value)
    console.log("Значение ключа", full_key);
    
    if (local_or_no(localStorage_or_no))         
        { console.log("Связь ключа в локальном хранилище");
        if (localStorage.getItem(full_key) == JSON.stringify(value)) 
            {setactive(localStorage_or_no, full_key, add_active)} 
        else
            { localStorage.setItem(full_key, JSON.stringify(value))
            setactive(localStorage_or_no, full_key, add_active) }
        return(full_key)
        }
    else
        { console.log("Связь ключа в локальной переменной");
        full_key=`${full_key}`
        if (localStorage_or_no[full_key] == value) {console.log("Значение в локальной переменной", localStorage_or_no[full_key], "Соответствует результату", value);
        setactive(localStorage_or_no, full_key, add_active)}
        else
            {console.log("Локальная переменная с ключом", JSON.stringify(full_key), "Со значением",localStorage_or_no[full_key], "Принимает значение",value);localStorage_or_no[full_key] = value; setactive(localStorage_or_no, full_key, add_active)} } }   

function inner(variable) {
    let inp_or_p=variable // Следующую строчку лучше скрыть
    let test_html=`
            <h1>Тест по математике</h1>
            <div class="form">
                <form name="test" novalidate>
                    <div class="quest">
                        <p>Чему равна сумма 3-х углов треугольника:</p>
                        <ul>
                            <li><${test_or_result[inp_or_p]} name="degree" value="0" checked>90°${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="degree" value="1">180°${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="degree" value="2">360°${end_p[inp_or_p]}</li>
                        </ul>
                    </div>
                    <div class="quest">
                        <p>Выберите правильный порядок математических действий:</p>
                        <ul>
                            <li><${test_or_result[inp_or_p]} name="order_operations" value="0" checked>Сначала выполняется умножение и деление, затем сложение и вычитание${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="order_operations" value="1">Сначала выполняется сложение и вычитание, затем умножение и деление${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="order_operations" value="2">Все действия выполняются по порядку слева направо, независимо от стоящих знаков${end_p[inp_or_p]}</li>
                        </ul>
                    </div>
                    <div class="quest">
                        <p>Как называются два треугольника с равными углами и пропорциональными сторонами:</p>
                        <ul>
                            <li><${test_or_result[inp_or_p]} name="similar" value="0" checked>Равносторонние${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="similar" value="1">Подобные${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="similar" value="2">Правильные${end_p[inp_or_p]}</li>
                        </ul>
                    </div>
                    <div class="quest">
                        <p>Что такое теорема:</p>
                        <ul>
                            <li><${test_or_result[inp_or_p]} name="theorem" value="0" checked>Математическое утверждение, истинность которого установлена путём доказательства${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="theorem" value="1">Исходное положение какой-либо теории, принимаемое в рамках данной теории истинным без требования доказательства${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="theorem" value="2">Предположение или догадка, которая требует доказательства${end_p[inp_or_p]}</li>
                        </ul>
                    </div>
                    <div class="quest">
                        <p>С каких двух чисел начинаются Числа Фибоначчи:</p>
                        <ul>
                            <li><${test_or_result[inp_or_p]} name="Fibonacchi" value="0" checked>0 и 1${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="Fibonacchi" value="1">1 и 3${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="Fibonacchi" value="2">0 и 2${end_p[inp_or_p]}</li>
                        </ul>
                    </div>
                    <div class="quest">
                        <p>Округлите десятичную дробь 3,65478 до сотых чисел:</p>
                        <input type="text" name="rounding" minlength="1" maxlength="5" placeholder="1,2345">
                    </div>
                    <div class="quest">
                        <p>Ось координат, которая проводится горизонтально, называется:</p>
                        <ul>
                            <li><${test_or_result[inp_or_p]} name="coordinates" value="0" checked>Ось абсцисс${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="coordinates" value="1">Ось ординат${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="coordinates" value="2">Ось аппликат${end_p[inp_or_p]}</li>
                        </ul>
                    </div>
                    <div class="quest">
                        <p>Чему равен квадратный корень числа 484:</p>
                        <ul>
                            <li><${test_or_result[inp_or_p]} name="root" value="0" checked>22${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="root" value="1">24${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="root" value="2">42${end_p[inp_or_p]}</li>
                        </ul>
                    </div>
                    <div class="quest">
                        <p>Чему равен модуль числа -7,8</p>
                        <ul>
                            <li><${test_or_result[inp_or_p]} name="module" value="0" checked>-7,8${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="module" value="1">7,8${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="module" value="2">8,7${end_p[inp_or_p]}</li>
                        </ul>
                    </div>
                    <div class="quest">
                        <p>Чтобы найти длину гипотенузы прямоугольного треугольника, нужно применить теорему:</p>
                        <ul>
                            <li><${test_or_result[inp_or_p]} name="Pythagoras" value="0" checked>Декарта${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="Pythagoras" value="1">Пифагора${end_p[inp_or_p]}</li>
                            <li><${test_or_result[inp_or_p]} name="Pythagoras" value="2">Пуанкаре${end_p[inp_or_p]}</li>
                        </ul>
                    </div>

                    <div class="center"><input type="submit" value="Сдать"></div>
                </form>
            </div>
            `
    return(test_html)
}



function login() {
        stroka = ""
        if (verify_name.test(form_account.name.value)&& //Проверка имени на соответствие
            verify_date.test(form_account.date.value)&& //Проверка даты на соответствие
            form_account.sex.value != 0) //Проверка выбора пола
            
            {
            err_account[0].classList.remove("showup")
            err_account[1].classList.remove("showup")
            err_account[2].classList.remove("showleft")
            account.name=form_account.name.value
            account.date=form_account.date.value
            account.sex=form_account.sex.value

            
            session=set_object_new_attribute("session", account, "localStorage", "active_session")
            
            for ( let i = 0; i<nolog.length;i++) {nolog[i].classList.remove("hide")}
            
            stroka=`Имя:${account["name"]}\nДата:${account["date"]}\nПол:${account["sex"]}`

            account_information.innerText = stroka
            look_test()
            }
        else
            {
            if (!verify_name.test(form_account.name.value)) 
                {err_account[0].classList.add("showup")}
            else{err_account[0].classList.remove("showup")}
            
            if (!verify_date.test(form_account.date.value)) 
                {err_account[1].classList.add("showup")}
            else{err_account[1].classList.remove("showup")}

            if (!(form_account.sex.value == "1" || form_account.sex.value == "2")) 
                {err_account[2].classList.add("showleft")}
            else{err_account[2].classList.remove("showleft")}
            }
}

function go_start() {
    if (reg.classList.contains("look")) {}
    else{reg.classList.add("look")}
    if (test.classList.contains("look")) {test.classList.remove("look")}
    if (result.classList.contains("look")) {result.classList.remove("look")}
    for ( let i = 0; i<nolog.length;i++) {nolog[i].classList.add("hide")}
    account_information.innerText = ""
}

function logout() 
{   
    localStorage.removeItem("active_session")
    go_start()
}

function addtest() {
    list_rezult["degree"]=form_test.degree.value
    list_rezult["order_operations"]=form_test.order_operations.value
    list_rezult["similar"]=form_test.similar.value
    list_rezult["theorem"]=form_test.theorem.value
    list_rezult["Fibonacchi"]=form_test.Fibonacchi.value
    list_rezult["rounding"]=form_test.rounding.value
    list_rezult["coordinates"]=form_test.coordinates.value
    list_rezult["root"]=form_test.root.value
    list_rezult["module"]=form_test.module.value
    list_rezult["Pythagoras"]=form_test.Pythagoras.value
    console.log(list_rezult);
    account = JSON.parse(localStorage[session])
    console.log(account);
    let new_result = `${session}`+"_"
    console.log("-------------------------------------------------------------------------------");
    set_object_new_attribute(new_result,list_rezult, account, session)
    
    
    // test.classList.remove("look")
    
}

function look_test() {
    reg.classList.remove("look")
    result.classList.remove("look")
    
    form_account.reset()
    
    test.innerHTML=inner("inp")
    
    form_test = document.forms.test
    test.classList.add("look")
    form_test.addEventListener("submit", (event2) =>
        {
            event2.preventDefault()
            addtest()})
}

function look_result() {
    reg.classList.remove("look")
    test.classList.remove("look")

    form_test.reset()

    
    result.classList.add("look")
}

form_account.addEventListener('submit', (event1) =>
    {
        event1.preventDefault()
        login()
    })



unreg.addEventListener("click", logout)

del.addEventListener("click", ()=>{localStorage.clear(); go_start()})